import requests
import json
from flask import request
import ast


def get_data_from_url():
    index_name = request.headers["X-Fission-Params-Indexname"]
    if index_name == "accidents":
        url = "http://router.fission.svc.cluster.local/extract/accidents"
    elif index_name == "weather":
        url = "http://router.fission.svc.cluster.local/extract/weather"
    response = requests.get(url, verify=False)
    data = json.loads(response.text)["messages"]
    return data


def main():
    data = get_data_from_url()

    actions = []
    for obs in data:
        action = {
            "_index": "accidents",
            "_id": obs["_id"],
            "_op_type": "index",
            "_source": {
                key: obs[key]
                for key in obs
                if key
                not in [
                    "_id",
                    "RMA",
                    "DAY_WEEK_DESC",
                    "DCA_CODE",
                    "DCA_DESC",
                    "LIGHT_CONDITION",
                    "POLICE_ATTEND",
                ]
            },
        }
        actions.append(action)
    return json.dumps(actions)
